#include "mw1.h"
#include <QApplication>
#include <QApplication>
#include <QtGui>

#include "myframe.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    MW1 mw;
    mw.show();
    MyFrame *frame = new MyFrame;
    frame->resize(400,800);
    frame->show();
    return a.exec();
}



